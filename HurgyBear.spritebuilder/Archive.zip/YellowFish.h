//
//  YellowFish.h
//  HurgyBear
//
//  Created by Nonpawit Teerachetmongkol on 12/11/2558 BE.
//  Copyright © 2558 Apportable. All rights reserved.
//

#import "CCNode.h"
#import "Fish.h"

@interface YellowFish : Fish

@end
